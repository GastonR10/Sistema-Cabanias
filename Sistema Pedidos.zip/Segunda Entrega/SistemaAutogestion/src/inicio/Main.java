package inicio;

import sistemaAutogestion.*;

public class Main {

    public static void main(String[] args) {

        Prueba p = new Prueba();
        Sistema s = new Sistema();
        p.inicializarResultadosPrueba();
        p1_creacionSistema(p, s);
        p2_crearCliente(p, s);
        p4_agregarProducto(p, s);
        p6_altaStockProducto(p, s);
        p7_aperturaDePedido(p, s);
        p8_agregarProductoAPedido(p, s);
        p9_deshacerPedido(p, s);
        p10_cerrarPedido(p, s);
        p11_procesarPedido(p, s);
        p3_eliminarCliente(p, s);// Para cumplir las validaciones es necesario ejecutar esta funcion a este momento.
        p5_eliminarProducto(p, s);// Para cumplir las validaciones es necesario ejecutar esta funcion a este momento.
        p12_listarClientes(p, s);
        p13_listarProductos(p, s);
        p14_listarPedidosAbiertos(p, s);
        p15_pedidosCerradosDeCliente(p, s);
        p16_productosParaEntregar(p, s);
        p17_reporteDePedidosSolicitadosXCliente(p, s);

        p.imprimirResultadosPrueba();

    }

    public static void p1_creacionSistema(Prueba p, Sistema s) {
        p.ver(s.crearSistemaDeAutoservicio(10).resultado, Retorno.Resultado.OK, "Se crea correctamente con 4 unidades");
        p.ver(s.crearSistemaDeAutoservicio(2).resultado, Retorno.Resultado.ERROR_1, "No se crea, maximo menor o igual a 3");
        p.ver(s.crearSistemaDeAutoservicio(3).resultado, Retorno.Resultado.ERROR_1, "No se crea, maximo menor o igual a 3");
    }

    public static void p2_crearCliente(Prueba p, Sistema s) {
        p.ver(s.agregarCliente("Lionel", "1234567", 6283518).resultado, Retorno.Resultado.OK, "Se crea correctamente nuevo cliente");
        p.ver(s.agregarCliente("Paredes", "7654321", 7073384).resultado, Retorno.Resultado.OK, "Se crea correctamente nuevo cliente");
        p.ver(s.agregarCliente("Lionel", "1234567", 62532518).resultado, Retorno.Resultado.ERROR_1, "Cliente ya existe");
        p.ver(s.agregarCliente("Forlan", "128778", 6183518).resultado, Retorno.Resultado.OK, "Se crea correctamente nuevo cliente");
        p.ver(s.agregarCliente("Lucho", "1282238", 6201518).resultado, Retorno.Resultado.OK, "Se crea correctamente nuevo cliente");
        p.ver(s.agregarCliente("Cristina", "4012238", 6283428).resultado, Retorno.Resultado.OK, "Se crea correctamente nuevo cliente");
        p.ver(s.agregarCliente("Marge", "1287238", 5452345).resultado, Retorno.Resultado.OK, "Se crea correctamente nuevo cliente");
        p.ver(s.agregarCliente("Marge", "1287238", 5457645).resultado, Retorno.Resultado.ERROR_1, "Cliente ya existe");
        p.ver(s.agregarCliente("Leonardo", "112233", 6283222).resultado, Retorno.Resultado.OK, "Se crea correctamente nuevo cliente");
        p.ver(s.agregarCliente("Rafael", "112244", 4444444).resultado, Retorno.Resultado.OK, "Se crea correctamente nuevo cliente");
        p.ver(s.agregarCliente("Donatelo", "112255", 5455545).resultado, Retorno.Resultado.OK, "Se crea correctamente nuevo cliente");
        p.ver(s.agregarCliente("Miguel Angel", "112266", 6666666).resultado, Retorno.Resultado.OK, "Se crea correctamente nuevo cliente");
    }

    public static void p3_eliminarCliente(Prueba p, Sistema s) {

        p.ver(s.eliminarCliente("7654321").resultado, Retorno.Resultado.OK, "Se borra el cliente con ci 7654321");
        p.ver(s.eliminarCliente("7654321").resultado, Retorno.Resultado.ERROR_1, "Cliente no encontrado");
        p.ver(s.eliminarCliente("1212").resultado, Retorno.Resultado.ERROR_1, "Cliente no encontrado");
        p.ver(s.eliminarCliente("112266").resultado, Retorno.Resultado.ERROR_2, "Este cliente tiene pedidos registrados");

    }

    public static void p4_agregarProducto(Prueba p, Sistema s) {
        p.ver(s.agregarProducto("Messi Burger", "Campeona del mundo").resultado, Retorno.Resultado.OK, "Se creo nuevo producto");
        p.ver(s.agregarProducto("Paredes Burger", "Campeona del mundo").resultado, Retorno.Resultado.OK, "Se creo nuevo producto");
        p.ver(s.agregarProducto("Paredes Burger", "Lechuga y tomate").resultado, Retorno.Resultado.ERROR_1, "Se intenta crea un producto con nombre igual a uno ya existente");
        p.ver(s.agregarProducto("G Burger", "Receta secreta de Gaston").resultado, Retorno.Resultado.OK, "Se creo nuevo producto");
        p.ver(s.agregarProducto("I Burger", "Receta secreta de Ignacio").resultado, Retorno.Resultado.OK, "Se creo nuevo producto");
        p.ver(s.agregarProducto("Vegan Burger", "Burger vegana para entendidos").resultado, Retorno.Resultado.OK, "Se creo nuevo producto");
        p.ver(s.agregarProducto("Vegan Burger", "Burger vegana para entendidos").resultado, Retorno.Resultado.ERROR_1, "Se intenta crea un producto con nombre igual a uno ya existente");
        p.ver(s.agregarProducto("American Burger", "Burguer Yankee").resultado, Retorno.Resultado.OK, "Se creo nuevo producto");
        p.ver(s.agregarProducto("Messi Pizza", "Estilo tortuga").resultado, Retorno.Resultado.OK, "Se creo nuevo producto");
        p.ver(s.agregarProducto("Messi cangrejo", "Estilo cangrejo").resultado, Retorno.Resultado.OK, "Se creo nuevo producto");

    }

    public static void p5_eliminarProducto(Prueba p, Sistema s) {
        p.ver(s.eliminarProducto("Messi Burger").resultado, Retorno.Resultado.OK, "Producto eliminado");
        p.ver(s.eliminarProducto("Messi Burger").resultado, Retorno.Resultado.ERROR_1, "Producto no encontrado");
        p.ver(s.eliminarProducto("I Burger").resultado, Retorno.Resultado.OK, "Producto eliminado");
        p.ver(s.eliminarProducto("I Burger").resultado, Retorno.Resultado.ERROR_1, "Producto no encontrado");
        p.ver(s.eliminarProducto("Messi Pizza").resultado, Retorno.Resultado.ERROR_2, "Producto en uso");
    }

    public static void p6_altaStockProducto(Prueba p, Sistema s) {
        p.ver(s.altaStockProducto(2, 8).resultado, Retorno.Resultado.OK, "Stock actualizado");
        p.ver(s.altaStockProducto(100, 4).resultado, Retorno.Resultado.ERROR_1, "Producto no encontrado");
        p.ver(s.altaStockProducto(2, 4).resultado, Retorno.Resultado.OK, "Stock actualizado");
        p.ver(s.altaStockProducto(2, -8).resultado, Retorno.Resultado.ERROR_2, "Unidades debe ser mayor a 0");
        p.ver(s.altaStockProducto(6, 2).resultado, Retorno.Resultado.OK, "Stock actualizado");
        p.ver(s.altaStockProducto(7, 40).resultado, Retorno.Resultado.OK, "Stock actualizado");
        p.ver(s.altaStockProducto(8, 30).resultado, Retorno.Resultado.OK, "Stock actualizado");

    }

    public static void p7_aperturaDePedido(Prueba p, Sistema s) {
        p.ver(s.aperturaDePedido("1234567").resultado, Retorno.Resultado.OK, "Nuevo pedido abierto");
        p.ver(s.aperturaDePedido("1234567").resultado, Retorno.Resultado.ERROR_2, "Solo puede haber un pedido abierto");
        p.ver(s.aperturaDePedido("8888888").resultado, Retorno.Resultado.ERROR_1, "No existe cliente con esa cedula");
        p.ver(s.aperturaDePedido("4012238").resultado, Retorno.Resultado.OK, "Nuevo pedido abierto");
        p.ver(s.aperturaDePedido("112233").resultado, Retorno.Resultado.OK, "Nuevo pedido abierto");
        p.ver(s.aperturaDePedido("112244").resultado, Retorno.Resultado.OK, "Nuevo pedido abierto");
        p.ver(s.aperturaDePedido("112255").resultado, Retorno.Resultado.OK, "Nuevo pedido abierto");
        p.ver(s.aperturaDePedido("112266").resultado, Retorno.Resultado.OK, "Nuevo pedido abierto");
        p.ver(s.aperturaDePedido("1282238").resultado, Retorno.Resultado.OK, "Nuevo pedido abierto");
       
    }

    public static void p8_agregarProductoAPedido(Prueba p, Sistema s) {
        p.ver(s.agregarProductoAPedido("1234567", 2, 4).resultado, Retorno.Resultado.OK, "Nueva linea agregada a pedido");
        p.ver(s.agregarProductoAPedido("88888888", 2, 4).resultado, Retorno.Resultado.ERROR_1, "No hay cliente con esa CI");
        p.ver(s.agregarProductoAPedido("1234567", 99, 4).resultado, Retorno.Resultado.ERROR_2, "No hay producto con ese numero");
        p.ver(s.agregarProductoAPedido("1234567", 2, 7).resultado, Retorno.Resultado.ERROR_3, "Se supera cantidad de unidades por pedido");
        p.ver(s.agregarProductoAPedido("1234567", 2, 0).resultado, Retorno.Resultado.ERROR_4, "Las unidades deben ser un numero positivo");
        p.ver(s.agregarProductoAPedido("1234567", 2, -1).resultado, Retorno.Resultado.ERROR_4, "Las unidades deben ser un numero positivo");
        p.ver(s.agregarProductoAPedido("1234567", 6, 3).resultado, Retorno.Resultado.ERROR_5, "No hay stock del material agregado");

        p.ver(s.agregarProductoAPedido("1234567", 6, 1).resultado, Retorno.Resultado.OK, "Nueva linea agregada a pedido");
        p.ver(s.agregarProductoAPedido("4012238", 6, 1).resultado, Retorno.Resultado.OK, "Nueva linea agregada a pedido");
        p.ver(s.agregarProductoAPedido("1234567", 2, 4).resultado, Retorno.Resultado.OK, "Nueva linea agregada a pedido");
        p.ver(s.agregarProductoAPedido("112266", 7, 4).resultado, Retorno.Resultado.OK, "Nueva linea agregada a pedido");
        p.ver(s.agregarProductoAPedido("112266", 8, 2).resultado, Retorno.Resultado.OK, "Nueva linea agregada a pedido");
        p.ver(s.agregarProductoAPedido("1282238", 7, 5).resultado, Retorno.Resultado.OK, "Nueva linea agregada a pedido");
        p.ver(s.agregarProductoAPedido("1282238", 8, 3).resultado, Retorno.Resultado.OK, "Nueva linea agregada a pedido");

    }

    public static void p9_deshacerPedido(Prueba p, Sistema s) {
        p.ver(s.deshacerPedido("1234567", 2).resultado, Retorno.Resultado.OK, "Se eliminan las ultimas lineas");
        p.ver(s.deshacerPedido("9999999", 2).resultado, Retorno.Resultado.ERROR_1, "No existe cliente");
        p.ver(s.deshacerPedido("4012238", 0).resultado, Retorno.Resultado.ERROR_2, "Numero de acciones debe ser mayor a 0");
        p.ver(s.deshacerPedido("4012238", 2).resultado, Retorno.Resultado.ERROR_3, "Numero de acciones a borrar no puede superar la cantidad de lineas del pedido");
        p.ver(s.deshacerPedido("4012238", 1).resultado, Retorno.Resultado.OK, "Se eliminan las ultimas lineas");

    }

    public static void p10_cerrarPedido(Prueba p, Sistema s) {
        p.ver(s.cerrarPedido("1234567").resultado, Retorno.Resultado.OK, "Se cierra pedido");
        p.ver(s.cerrarPedido("7777777").resultado, Retorno.Resultado.ERROR_1, "No existe cliente");
        p.ver(s.cerrarPedido("1287238").resultado, Retorno.Resultado.ERROR_2, "Cliente no tiene pedido abierto");
        p.ver(s.cerrarPedido("112266").resultado, Retorno.Resultado.OK, "Se cierra pedido");
        p.ver(s.cerrarPedido("1282238").resultado, Retorno.Resultado.OK, "Se cierra pedido");

    }

    public static void p11_procesarPedido(Prueba p, Sistema s) {
        p.ver(s.procesarPedido(1).resultado, Retorno.Resultado.OK, "Se procesa pedido");
        p.ver(s.procesarPedido(0).resultado, Retorno.Resultado.ERROR_1, "Cantidad de pedidos a procesar debe ser mayor a 0");
        p.ver(s.procesarPedido(100).resultado, Retorno.Resultado.ERROR_2, "No hay tantos pedidos cerrados");

    }

    public static void p12_listarClientes(Prueba p, Sistema s) {
        p.ver(s.listarClientes().resultado, Retorno.Resultado.OK, "Se muestra lista de clientes");

    }

    public static void p13_listarProductos(Prueba p, Sistema s) {
        p.ver(s.listarProductos().resultado, Retorno.Resultado.OK, "Se muestra lista de productos");

    }

    public static void p14_listarPedidosAbiertos(Prueba p, Sistema s) {
        p.ver(s.listarPedidosAbiertos().resultado, Retorno.Resultado.OK, "Se muestra lista de pedidos abiertos");

    }

    public static void p15_pedidosCerradosDeCliente(Prueba p, Sistema s) {
        p.ver(s.pedidosCerradosDeCliente("112266").resultado, Retorno.Resultado.OK, "Se muestra lista de pedidos cerrados del cliente");
        p.ver(s.pedidosCerradosDeCliente("1090909").resultado, Retorno.Resultado.ERROR_1, "No existe cliente con esa CI");
    }

    public static void p16_productosParaEntregar(Prueba p, Sistema s) {
        p.ver(s.productosParaEntregar().resultado, Retorno.Resultado.OK, "Se muestra lista de pedidos listos para entregar");
    }

    public static void p17_reporteDePedidosSolicitadosXCliente(Prueba p, Sistema s) {
        p.ver(s.reporteDePedidosSolicitadosXCliente().resultado, Retorno.Resultado.OK, "Se muestra matriz");
    }
}
