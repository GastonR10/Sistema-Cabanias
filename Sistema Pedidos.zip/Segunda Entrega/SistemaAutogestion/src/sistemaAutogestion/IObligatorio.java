package sistemaAutogestion;


public interface IObligatorio {
    
    /*
    **************** REGISTRO DE CLIENTES Y PRODUCTOS **************************************
    */
    
    /*
    pre: maxUnidadesDePedido de pedido es un entero    
    post: Se crea la estructura necesaria para representar el sistema.
    */
    public Retorno crearSistemaDeAutoservicio(int maxUnidadesDePedido);
    
    /*
    pre: nombre es de tipo string y no vacío
         ci es de tipo string y no vacío
         tel tipo int y no vacío
    post: Se agrega un nuevo cliente a la lista de clientes siempre y cuando 
          no haya uno ya creado con la misma ci
    */
    public Retorno agregarCliente(String nombre,String ci,int tel);
    
    /*
    pre: ci de tipo string y no vacío      
    post: Se borra de la lista clientes el cliente con el numero de ci ingresado
          siempre y cuando no tenga pedidos registrados
    */
    public Retorno eliminarCliente(String ci);
    
    /*
    pre: nombre es de tipo string y no vacío, 
         descripcion es de tipo string y no vacío
    post: se agrega un producto a la lista productos, con id autogenerado, 
          siempre que el nombre no se repita con los ya existentes.
    */
    public Retorno agregarProducto(String nombre, String descripcion); 
    
    /*
    pre: nombre de tipo de tipo string y no vacío 
    post: se elimina el producto con el nombre ingresado
    */
    public Retorno eliminarProducto(String nombre);
    
    /*
    pre: nroProducto de tipo string y no vacío
         unidades de tipo entero y mayor a 0
    post: se incrementa el numero de stock del producto indicado
    */
    public Retorno altaStockProducto(int nroProducto, int unidades);
    
     /*
    **************** GESTIÓN DE PEDIDOS **************************************
    */
    
    
    /*
    pre: ciCLiente de tipo string y no vacio
    post: se abre un nuevo pedido del cliente ingresado
    */
    public Retorno aperturaDePedido(String ciCliente);
    
    /*
    pre:  ciCliente de tipo string y no vacio
          nroProducto de tipo entero y no vacio
          unidades de tipo entero y no vacio
    post: Agrega una cantidad especifica de determinado producto a un pedido
    */
    public Retorno agregarProductoAPedido(String ciCliente, int nroProducto, int unidades); 
    
    /*
    pre:  ciCliente de tipo string y no vacio
          cantAccionesDesahacer numero entero 
    post: Se deshacen las ultimas acciones del pedido en la cantidad indicada
    */
    public Retorno deshacerPedido(String ciCliente, int cantAccionesDeshacer);
    
    /*
    pre:  ciCliente de tipo string y no vacio
    post: se cierra el pedido siempre y cuando que el ci sea de una cliente existente
    */
    public Retorno cerrarPedido(String ciCliente); 
    
    /*
    pre: cantPedidos es un numero entero
    post: procesa pedidos cerrados en orden de llegada y los mismos deben pasar de estado de "Prontos para entregar"
    */
    public Retorno procesarPedido(int cantPedidos); 
    
      /*
    **************** LISTADO Y REPORTES **************************************
    */
    
     
    /*
    pre:  El sistema cuenta con una lista de clientes   
    post: Se lista los clientes ordenados por orden alfabetico. Se muestan todos sus datos
    */
    public Retorno listarClientes();
     
    /*
    pre:  El sistema cuenta con una lista de productos
    post: Se muestran todos los productos en el orden que fueron registrados. Se muestra sus datos y el stock disponible 
         de dicho producto.
    */
    public Retorno listarProductos();
     
    /*
    pre:    El sistema cuenta con lista de pedidos que pueden ser abiertos o no  
    post: : Lista todos los pedidos abiertos con sus productos  y unidades solicitadas. Se muestran todos sus datos y su stock disponible.
    */
    public Retorno listarPedidosAbiertos();
     
    /*
    pre:  los clientes cuentan con pedidos que pueden estar en estado "cerrados"
    post: lista todos los pedidos cerrados del cliente indicado
    */
    public Retorno pedidosCerradosDeCliente(String ci);
    
    /*
    pre:  Los pedidos pueden estar en estado "pronto para entregar"    
    post: Se muestra numero y cliente de los pedidos pronto para entregar
    */
    public Retorno productosParaEntregar();
    
    /*
    pre:  Los pedidos tienen una lista de productos con su respectiva cantidad.    
    post: Se muestra una matriz donde, para cada pedido (filas) se muestran la cantidad de unidades ingresadas para cada 
          producto (columnas)
    */
    public Retorno reporteDePedidosSolicitadosXCliente();
    
}
