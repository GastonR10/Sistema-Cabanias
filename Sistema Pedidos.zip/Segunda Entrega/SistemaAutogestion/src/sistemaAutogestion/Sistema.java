package sistemaAutogestion;

import clases.*;
import tads.*;

public class Sistema implements IObligatorio {

    public ListaNodo<Cliente> listaClientes;
    public ListaNodo<Producto> listaProductos;
    public ColaNodo<Pedido> colaPedidosCerrados;
    public ListaNodo<Pedido> listaPedidosParaEntregar;

    public int maxUnidades;

    @Override
    public Retorno crearSistemaDeAutoservicio(int maxUnidadesDePedido) {

        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        if (maxUnidadesDePedido <= 3) {
            r.resultado = Retorno.Resultado.ERROR_1;
        } else {
            listaClientes = new ListaNodo();
            listaProductos = new ListaNodo();
            colaPedidosCerrados = new ColaNodo();
            listaPedidosParaEntregar = new ListaNodo();
            maxUnidades = maxUnidadesDePedido;

            r.resultado = Retorno.Resultado.OK;
        }

        return r;
    }

    @Override
    public Retorno agregarCliente(String nombre, String ci, int tel) {

        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);
        Cliente nuevoCliente = new Cliente(nombre, ci, tel);

        if (listaClientes.existeDato(nuevoCliente)) {
            r.resultado = Retorno.Resultado.ERROR_1;
        } else {
            listaClientes.agregarOrd(nuevoCliente);
            r.resultado = Retorno.Resultado.OK;
        }

        return r;
    }

    @Override
    public Retorno eliminarCliente(String ci) {

        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        Cliente clienteAux = new Cliente("Aux", ci, 0);

        if (!listaClientes.existeDato(clienteAux)) {

            r.resultado = Retorno.Resultado.ERROR_1;
        } else {
            Cliente cliente = (Cliente) listaClientes.obtenerElemento(clienteAux).getDato();

            if (cliente.getCantPedidosRegistrados() > 0) {
                r.resultado = Retorno.Resultado.ERROR_2;
            } else {

                listaClientes.borrarElemento(cliente);
                r.resultado = Retorno.Resultado.OK;
            }
        }
        return r;
    }

    @Override
    public Retorno agregarProducto(String nombre, String descripcion) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        Producto nuevoProd = new Producto(nombre, descripcion);

        if (!listaProductos.existeDato(nuevoProd)) {
            Producto.ultimoId++;
            listaProductos.agregarFinal(nuevoProd);
            r.resultado = Retorno.Resultado.OK;

        } else {
            r.resultado = Retorno.Resultado.ERROR_1;
        }

        return r;
    }

    @Override
    public Retorno eliminarProducto(String nombre) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        Producto productoAux = new Producto(nombre, "descripcion aux");

        if (!listaProductos.existeDato(productoAux)) {

            r.resultado = Retorno.Resultado.ERROR_1;
        } else {
            Producto producto = (Producto) listaProductos.obtenerElemento(productoAux).getDato();
            if (producto.getCantUsos() > 0) {
                r.resultado = Retorno.Resultado.ERROR_2;
            } else {

                listaProductos.borrarElemento(producto);
                r.resultado = Retorno.Resultado.OK;

            }
        }
        return r;
    }

    @Override
    public Retorno altaStockProducto(int nroProducto, int unidades) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        Producto productoAux = new Producto("NombreAux", "DescAux");

        productoAux.setIdProducto(nroProducto);

        if (!listaProductos.existeDato(productoAux)) {
            r.resultado = Retorno.Resultado.ERROR_1;

        } else {

            if (unidades <= 0) {
                r.resultado = Retorno.Resultado.ERROR_2;
            } else {
                Producto producto = (Producto) listaProductos.obtenerElemento(productoAux).getDato();
                producto.setStock(producto.getStock() + unidades);
                r.resultado = Retorno.Resultado.OK;
            }
        }

        return r;
    }

    @Override
    public Retorno aperturaDePedido(String ciCliente) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        Cliente clienteAux = new Cliente("nombre aux", ciCliente, 0);

        if (!listaClientes.existeDato(clienteAux)) {
            r.resultado = Retorno.Resultado.ERROR_1;
        } else {
            Cliente cliente = (Cliente) listaClientes.obtenerElemento(clienteAux).getDato();

            if (!cliente.getPedidosCliente().esVacia() && cliente.getPedidosCliente().cima().getDato().getEstado().equals("abierto")) {

                r.resultado = Retorno.Resultado.ERROR_2;

            } else {

                Pedido nuevoPedido = new Pedido(ciCliente);
                Pedido.ultimoId++;
                cliente.setPedidosCliente(nuevoPedido);
                cliente.setCantPedidosRegistrados(cliente.getCantPedidosRegistrados() + 1);

                r.resultado = Retorno.Resultado.OK;
            }
        }

        return r;
    }

    @Override
    public Retorno agregarProductoAPedido(String ciCliente, int nroProducto, int unidades) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        Cliente clienteAux = new Cliente("nombre aux", ciCliente, 0);
        Producto productoAux = new Producto("NombreAux", "DescAux");
        productoAux.setIdProducto(nroProducto);

        if (!listaClientes.existeDato(clienteAux)) {
            r.resultado = Retorno.Resultado.ERROR_1;
        } else {
            Cliente cliente = (Cliente) listaClientes.obtenerElemento(clienteAux).getDato();

            if (!listaProductos.existeDato(productoAux)) {
                r.resultado = Retorno.Resultado.ERROR_2;
            } else {
                Producto producto = (Producto) listaProductos.obtenerElemento(productoAux).getDato();
                Linea linea = new Linea(producto, unidades);
                Pedido pedidoAbierto = cliente.getPedidosCliente().cima().getDato();

                if (pedidoAbierto.getCantUnidades() + linea.getCantidad() > maxUnidades) {
                    r.resultado = Retorno.Resultado.ERROR_3;
                } else if (unidades <= 0) {
                    r.resultado = Retorno.Resultado.ERROR_4;
                } else if (producto.getStock() < unidades) {
                    r.resultado = Retorno.Resultado.ERROR_5;
                } else {
                    cliente.getPedidosCliente().cima().getDato().setLineas(linea);
                    producto.setStock(producto.getStock() - unidades);
                    producto.setCantUsos(producto.getCantUsos() + 1);
                    r.resultado = Retorno.Resultado.OK;
                }
            }
        }

        return r;
    }

    @Override
    public Retorno deshacerPedido(String ciCliente, int cantAccionesDeshacer) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        Cliente clienteAux = new Cliente("nombre aux", ciCliente, 0);

        if (!listaClientes.existeDato(clienteAux)) {
            r.resultado = Retorno.Resultado.ERROR_1;
        } else {

            if (cantAccionesDeshacer <= 0) {
                r.resultado = Retorno.Resultado.ERROR_2;
            } else {
                Cliente cliente = (Cliente) listaClientes.obtenerElemento(clienteAux).getDato();

                if (cantAccionesDeshacer > cliente.getPedidosCliente().cima().getDato().getLineas().getCantElementos()) {
                    r.resultado = Retorno.Resultado.ERROR_3;
                } else {
                    for (int i = 0; i < cantAccionesDeshacer; i++) {
                        Linea lineaABorrar = cliente.getPedidosCliente().cima().getDato().getLineas().cima().getDato();
                        lineaABorrar.getProducto().setStock(lineaABorrar.getProducto().getStock() + lineaABorrar.getCantidad());
                        lineaABorrar.getProducto().setCantUsos(lineaABorrar.getProducto().getCantUsos() - 1);
                        cliente.getPedidosCliente().cima().getDato().getLineas().desapilar();
                    }
                    r.resultado = Retorno.Resultado.OK;
                }
            }
        }

        return r;
    }

    @Override
    public Retorno cerrarPedido(String ciCliente) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        Cliente clienteAux = new Cliente("nombre aux", ciCliente, 0);

        if (!listaClientes.existeDato(clienteAux)) {
            r.resultado = Retorno.Resultado.ERROR_1;
        } else {
            Cliente cliente = (Cliente) listaClientes.obtenerElemento(clienteAux).getDato();
            if (cliente.getPedidosCliente().esVacia()
                    || cliente.getPedidosCliente().cima().getDato().getEstado().equals("cerrado")) {
                r.resultado = Retorno.Resultado.ERROR_2;
            } else {
                Pedido pedidoACerrar = cliente.getPedidosCliente().cima().getDato();
                pedidoACerrar.setEstado("cerrado");
                colaPedidosCerrados.encolar(pedidoACerrar);
                cliente.setPedidosCerradosProcesados(pedidoACerrar);
                r.resultado = Retorno.Resultado.OK;
            }
        }
        return r;
    }

    @Override
    public Retorno procesarPedido(int cantPedidos) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        if (cantPedidos <= 0) {
            r.resultado = Retorno.Resultado.ERROR_1;
        } else {

            if (cantPedidos > colaPedidosCerrados.getCantElementos()) {
                r.resultado = Retorno.Resultado.ERROR_2;
            } else {
                for (int i = 0; i < cantPedidos; i++) {
                    Pedido primerPedido = colaPedidosCerrados.obtenerPrimero();
                    primerPedido.setEstado("Prontos para entregar");
                    if (primerPedido.getLineas().getDato() != null) {
                        primerPedido.getLineas().getDato().getProducto().setCantUsos(primerPedido.getLineas().getDato().getProducto().getCantUsos() - 1);
                    }
                    Cliente clienteAux = new Cliente("aux", primerPedido.getCiCliente(), 0);
                    Cliente cliente = (Cliente) listaClientes.obtenerElemento(clienteAux).getDato();
                    cliente.setCantPedidosRegistrados(cliente.getCantPedidosRegistrados() - 1);

                    listaPedidosParaEntregar.agregarFinal(primerPedido);
                    colaPedidosCerrados.desencolar();

                }
                r.resultado = Retorno.Resultado.OK;
            }
        }

        return r;
    }

    @Override
    public Retorno listarClientes() {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        listaClientes.mostrar();

        r.resultado = Retorno.Resultado.OK;
        return r;
    }

    @Override
    public Retorno listarProductos() {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        listaProductos.mostrar();// mostrar() es recursiva.

        r.resultado = Retorno.Resultado.OK;
        return r;
    }

    @Override
    public Retorno listarPedidosAbiertos() {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        Nodo<Cliente> cliente = listaClientes.getInicio();
        while (cliente != null) {
            if (!cliente.getDato().getPedidosCliente().esVacia() && cliente.getDato().getPedidosCliente().cima().getDato().getEstado() == "abierto") {
                System.out.println(cliente.getDato().getPedidosCliente().cima().getDato());
            }
            cliente = cliente.getSiguiente();
        }
        r.resultado = Retorno.Resultado.OK;
        return r;
    }

    @Override
    public Retorno pedidosCerradosDeCliente(String ci) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);
        Cliente clienteAux = new Cliente("nombre aux", ci, 0);
        if (!listaClientes.existeDato(clienteAux)) {
            r.resultado = Retorno.Resultado.ERROR_1;
        } else {
            Cliente cliente = (Cliente) listaClientes.obtenerElemento(clienteAux).getDato();

            ListaNodo<Pedido> pedidosCerrados = new ListaNodo<Pedido>();
            Nodo<Pedido> pedido = cliente.getPedidosCerradosProcesados().getInicio();

            while (pedido != null) {
                if (pedido.getDato().getEstado() == "cerrado") {
                    pedidosCerrados.agregarFinal(pedido.getDato());

                }
                pedido = pedido.getSiguiente();

            }

            pedidosCerrados.mostrar();
            r.resultado = Retorno.Resultado.OK;
        }
        return r;
    }

    @Override
    public Retorno productosParaEntregar() {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);
        ListaNodo<Pedido> listaAux = listaPedidosParaEntregar;

        productosParaEntregarRec(listaAux);

        r.resultado = Retorno.Resultado.OK;
        return r;
    }
    //Funcion recursiva de productos para entregar
    public void productosParaEntregarRec(ListaNodo<Pedido> lista) {

        if (lista.getInicio() == null) {
        } else {
            Cliente aux = new Cliente("", lista.getFin().getDato().getCiCliente(), 0);
            if (listaClientes.existeDato(aux)) {
                Cliente cliente = (Cliente) listaClientes.obtenerElemento(aux).getDato();

                System.out.println("Numero de pedido: " + lista.getFin().getDato().getIdPedido() + " Cliente: " + cliente.getNombre());
                lista.borrarFin();
                productosParaEntregarRec(lista);
            }
        }

    }

    @Override
    public Retorno reporteDePedidosSolicitadosXCliente() {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        int cantClientes = listaClientes.cantElementos();
        int cantProd = listaProductos.cantElementos();

        String[][] matriz = new String[cantClientes+1][cantProd+1];//Mas uno para tener los encabezados y ci
        Nodo<Producto> producto = listaProductos.getInicio();
        Nodo<Cliente> cliente = listaClientes.getInicio();
        for (int i = 0; i <= cantClientes; i++) {

            for (int j = 0; j <= cantProd; j++) {
                if (i == 0 && j > 0) {

                    matriz[i][j] = producto.getDato().getNombre();
                    producto = producto.getSiguiente();
                } else if (i > 0 && j == 0) {

                    matriz[i][j] = cliente.getDato().getCi();
                    cliente = cliente.getSiguiente();
                } else if (i == 0 && j == 0) {
                    matriz[i][j] = "CI Cliente";
                } else {
                    matriz[i][j] = String.valueOf(cantPedidaProducto(matriz[i][0], matriz[0][j]));
                }
            }
        }

        mostrarMatrizXFilas(matriz);

        r.resultado = Retorno.Resultado.OK;
        return r;
    }

    //Recibe CI cliente y nombre de producto, y retorna la cantidad de unidades de ese producto que el cliente pidió. 
    public int cantPedidaProducto(String cliCi, String prodNombre) {
        int retorno = 0;
        Cliente clienteAux = new Cliente("", cliCi, 0);
        Cliente cliente = (Cliente) listaClientes.obtenerElemento(clienteAux).getDato();

        Nodo<Pedido> pedido = cliente.getPedidosCerradosProcesados().getInicio();

        while (pedido != null) {

            ListaNodo<Linea> listaLineas = pedido.getDato().getLineas().transformarEnLista();
            if (listaLineas != null) {
                Nodo<Linea> linea = listaLineas.getInicio();

                while (linea != null) {
                    if (prodNombre == linea.getDato().getProducto().getNombre()) {
                        retorno += linea.getDato().getCantidad();
                    }

                    linea = linea.getSiguiente();
                }
            }
            pedido = pedido.getSiguiente();

        }

        return retorno;
    }

    // pre: datos de tipo string, no nula, los nombres de los productos no van a tener mas de 18 caracteres
    // pos: se imprimen los datos de la matriz
    public static void mostrarMatrizXFilas(String[][] mat) {

        for (int i = 0; i < mat.length; i++) {

            for (int j = 0; j < mat[i].length; j++) {
                int caracteres = mat[i][j].length();
                System.out.print((" ".repeat(18 - caracteres)) + mat[i][j] + " ");
            }
            System.out.println("");
        }
    }

}
