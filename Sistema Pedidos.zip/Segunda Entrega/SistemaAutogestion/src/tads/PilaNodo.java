package tads;

public class PilaNodo<T extends Comparable<T>> implements IPila<T> {

    private Nodo<T> inicio;
    private T dato;
    private int cantElementos;

    //Constructor
    public PilaNodo() {

        inicio = null;
    }

    public Nodo<T> getInicio() {
        return inicio;
    }

    public void setInicio(Nodo inicio) {
        this.inicio = inicio;
    }

    public T getDato() {
        return dato;
    }

    public void setDato(T dato) {
        this.dato = dato;
    }

    public int getCantElementos() {
        return cantElementos;
    }

    public void setCantElementos(int cantElementos) {
        this.cantElementos = cantElementos;
    }

    @Override
    public void apilar(T dato) {

        Nodo<T> nuevo = new Nodo(dato);
        nuevo.setSiguiente(getInicio());
        inicio = nuevo;
        cantElementos++;

    }

    @Override
    public void desapilar() {
        if (!this.esVacia()) {
            inicio = getInicio().getSiguiente();
            cantElementos--;
        } else {
            System.out.println("Esta vacia");
        }
    }

    @Override
    public PilaNodo<T> copiarPila() {
        PilaNodo<T> aux = new PilaNodo<T>();
        PilaNodo<T> copia = new PilaNodo<T>();
        while (!this.esVacia()) {

            aux.apilar(inicio.getDato());
            this.desapilar();
        }

        while (!aux.esVacia()) {
            copia.apilar(aux.inicio.getDato());
            this.apilar(aux.inicio.getDato());
            aux.desapilar();
        }

        return copia;
    }
    // Pre: La pila tiene al menos dos elementos
//Pos: Intercambia los dos elementos del tope de la pila

    @Override
    public void intercambiarTope() {
        Nodo<T> aux = this.cima();
        this.desapilar();
        Nodo<T> aux2 = this.cima();
        this.desapilar();
        this.apilar(aux.getDato());
        this.apilar(aux2.getDato());

    }

    @Override
    public boolean esVacia() {
        return inicio == null;
    }

    @Override
    public Nodo<T> cima() {
        return this.getInicio();
    }

    @Override
    public int elementos() {
        return cantElementos;
    }

    @Override
    public void invertir() {

        ColaNodo<T> colaAux = new ColaNodo<T>();

        while (!this.esVacia()) {
            colaAux.encolar(this.cima().getDato());
            this.desapilar();
        }

        while (!colaAux.estaVacia()) {
            this.apilar(colaAux.obtenerPrimero());
            colaAux.desencolar();
        }
    }

    @Override
    public String mostrarPila() {

        PilaNodo<T> aux = new PilaNodo<T>();
        String mostrar = "";
        while (!this.esVacia()) {

            aux.apilar(this.inicio.getDato());
            this.desapilar();
        }

        while (!aux.esVacia()) {
            mostrar += aux.getInicio().getDato() + "\n";
            this.apilar(aux.inicio.getDato());
            aux.desapilar();
        }
         
        return mostrar;
    }
    
    
    
    @Override
    public ListaNodo<T> transformarEnLista(){
        
        ListaNodo<T> lista = new ListaNodo<T>();
        
        PilaNodo<T> aux = new PilaNodo<T>();
        
        while (!this.esVacia()) {

            aux.apilar(this.inicio.getDato());
            this.desapilar();
        }

        while (!aux.esVacia()) {
            lista.agregarFinal(aux.inicio.getDato());
            this.apilar(aux.inicio.getDato());
            aux.desapilar();
        }
         
        return lista;
        
    }

}
