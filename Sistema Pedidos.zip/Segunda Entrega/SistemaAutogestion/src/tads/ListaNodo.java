package tads;

public class ListaNodo<T extends Comparable<T>> implements ILista<T> {

    private Nodo<T> inicio;
    private int cantidad;
    private Nodo<T> fin;

    public ListaNodo() {
        inicio = null;
        cantidad = 0;
        fin = null;
    }

    @Override
    public boolean esVacia() {
        return inicio == null;
    }

    @Override
    public void agregarInicio(T n) {

        Nodo<T> nuevo = new Nodo(n);
        if (this.esVacia()) {
            fin = nuevo;
        }
        nuevo.setSiguiente(inicio);
        inicio = nuevo;
        cantidad++;

    }

    @Override
    public void mostrar() {
        mostrarRecursivo(getInicio());
        System.out.println("");
    }

    private void mostrarRecursivo(Nodo<T> nodo) {
        if (nodo == null) {
            
        } else {
            System.out.print(nodo.getDato());
            mostrarRecursivo(nodo.getSiguiente());
        }
        
    }

    @Override
    public void agregarFinal(T n) {

        if (this.esVacia()) {
            agregarInicio(n);

        } else {

            Nodo<T> nuevo = new Nodo(n);
            cantidad++;
            fin.setSiguiente(nuevo);
            fin = nuevo;
        }

    }

    @Override
    public void borrarInicio() {

        if (!esVacia()) {
            Nodo<T> borrar = inicio;
            inicio = inicio.getSiguiente();
            borrar.setSiguiente(null);
            cantidad--;
        } else {
            System.out.println("Esta vacia");
        }
    }

    @Override
    public void borrarFin() {
        if (!this.esVacia()) {

            if (cantidad == 1) {
                vaciar();
            } else {

                Nodo<T> actual = getInicio();

                while (actual.getSiguiente().getSiguiente() != null) {
                    actual = actual.getSiguiente();
                }
                actual.setSiguiente(null);
                fin = actual;
                cantidad--;
            }

        }
    }

    @Override
    public void borrarElemento(T n) {

        if (!this.esVacia()) {

            if (inicio.getDato() == n) {
                borrarInicio();
            } else if (fin.getDato() == n) {
                borrarFin();
            } else {

                Nodo<T> actual = inicio;

                while (actual.getSiguiente() != null && actual.getSiguiente().getDato() != n) {
                    actual = actual.getSiguiente();
                }

                if (actual.getSiguiente() != null) {
                    Nodo aBorrar = actual.getSiguiente();
                    actual.setSiguiente(aBorrar.getSiguiente());
                    aBorrar.setSiguiente(null);
                    cantidad--;
                }
            }
        }
    }

    @Override
    public void vaciar() {
        inicio = null;
        cantidad = 0;
        fin = null;
    }

    @Override
    public int cantElementos() {
        return cantidad;
    }

    @Override
    public Boolean existeDato(T dato) {
        Boolean existe = false;

        if (!esVacia()) {
            Nodo<T> actual = inicio;

            while (actual != null && !actual.getDato().equals(dato)) {
                actual = actual.getSiguiente();
            }

            if (actual != null) {
                existe = true;
            }

        }

        return existe;
    }

    @Override
    public Nodo<T> obtenerElemento(T t) {

        Nodo<T> ret = null;

        if (!this.esVacia()) {

            Nodo<T> actual = getInicio();

            while (actual != null && !actual.getDato().equals(t)) {
                actual = actual.getSiguiente();
            }

            if (actual != null) {
                ret = actual;
            }
        }

        return ret;
    }

    public Nodo<T> getInicio() {
        return inicio;
    }

    public Nodo<T> getFin() {
        return fin;
    }

    public int getCantidad() {
        return cantidad;
    }

    /*
    private void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
     */
    @Override
    public void agregarOrd(T t) {
        Nodo<T> nuevo = new Nodo(t);
        if (this.esVacia()) {
            agregarInicio(t);
        } else {
            if (getInicio().getDato().compareTo(t) > 0) {
                agregarInicio(t);
            } else if (getFin().getDato().compareTo(t) < 0) {
                agregarFinal(t);
            } else {
                Nodo<T> actual = getInicio();
                while (actual.getSiguiente() != null && actual.getSiguiente().getDato().compareTo(t) < 0) {
                    actual = actual.getSiguiente();
                }
                nuevo.setSiguiente(actual.getSiguiente());
                actual.setSiguiente(nuevo);
                cantidad++;
            }
        }

    }

}
