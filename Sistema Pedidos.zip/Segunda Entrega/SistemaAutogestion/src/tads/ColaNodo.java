package tads;


public class ColaNodo<T> implements ICola<T> {

    private Nodo<T> primero;
    private Nodo<T> ultimo;
    private int cantElementos;
    private T dato;

    public ColaNodo() {
        this.primero = null;
        this.ultimo = null;
    }

    public T getDato() {
        return dato;
    }
    
    public int getCantElementos() {
        return cantElementos;
    }

    public void setCantElementos(int cantElementos) {
        this.cantElementos = cantElementos;
    }
    
    @Override
    public boolean estaVacia() {
        return primero == null;
    }

    @Override
    public void encolar(T dato) {
        Nodo<T> nuevoNodo = new Nodo<T>(dato);
        if (estaVacia()) {
            primero = nuevoNodo;
        } else {
            ultimo.setSiguiente(nuevoNodo);
        }
        ultimo = nuevoNodo;
        cantElementos++;
    }

    @Override
    public void desencolar() {
        if (estaVacia()) {
            throw new IllegalStateException("La cola está vacía");
        }
        
        primero = primero.getSiguiente();
        if (primero == null) {
            ultimo = null;
        }
        cantElementos--;
    }

    @Override
    public T obtenerPrimero() {
        if (estaVacia()) {
            throw new IllegalStateException("La cola está vacía");
        }
        return primero.getDato();
    }

    @Override
    public void mostrarCola() {
        
        Nodo<T> aux = primero;
        
        System.out.println("Muestro Cola:");
        
        while(aux !=  null){
            System.out.print(aux.getDato() + " - ");
            aux = aux.getSiguiente();
        }  
    }    
       
}
