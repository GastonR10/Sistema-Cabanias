package tads;

public interface IPila<T> {

    public void apilar(T dato);

    public void desapilar();

    public boolean esVacia();

    public Nodo cima();

    public int elementos();

    public PilaNodo copiarPila();

    public void intercambiarTope();

    public void invertir();

    public String mostrarPila();
    
    public ListaNodo transformarEnLista();

}
