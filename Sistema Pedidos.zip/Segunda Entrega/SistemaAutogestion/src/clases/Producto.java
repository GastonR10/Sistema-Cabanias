package clases;

public class Producto implements Comparable<Producto>{

    private int idProducto;
    public static int ultimoId = 1;
    private String nombre;
    private String descripcion;
    private int stock;
    private int cantUsos = 0;

    public Producto(String unNombre, String unaDescripcion) {
        
        this.setIdProducto(ultimoId);
        this.setNombre(unNombre);
        this.setDescripcion(unaDescripcion);
    }

        public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProd) {
        this.idProducto = idProd;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    public int getStock() {
        return stock;
    }

   
    public void setStock(int unidades) {
        this.stock = unidades;
    }
    
    public int getCantUsos() {
        return cantUsos;
    }

   
    public void setCantUsos(int unidades) {
        this.cantUsos = unidades;
    }
   
   
        
    public boolean equals(Object a) {
        boolean retorno = false;
        Producto c = (Producto) a;
        
        if(this.getNombre().equals(c.getNombre()) || this.getIdProducto() == c.getIdProducto()){
            
            retorno = true;
        }
        
        return retorno;
    }
           
    @Override
    public String toString() {
        return "id: " + this.getIdProducto() + " Nombre: " + this.getNombre() + " Descripcion: " + this.getDescripcion() + " Stock: " + this.getStock() + " Usos: " + this.getCantUsos() + "\n";
    }
    
    @Override
    public int compareTo(Producto o) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
