package clases;


public class Linea implements Comparable <Linea>  {
    
    private Producto producto;
    private int cantidad;
    
    public Linea(Producto unProducto, int unaCantidad){
        this.setProducto(unProducto);
        this.setCantidad(unaCantidad);
    }
    
    public Producto getProducto(){
        return producto;
    }

    public void setProducto(Producto unProducto) {
        this.producto = unProducto;    
    }
    
    public int getCantidad(){
        return cantidad;
    }

    public void setCantidad(int unaCantidad) {
        this.cantidad = unaCantidad;
    }
    
    public String toString(){
        return "Producto: " + this.getProducto().getNombre()+ " Cantidad: " + this.getCantidad() ;
    }

    @Override
    public int compareTo(Linea o) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   
}
