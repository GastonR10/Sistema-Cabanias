package clases;

import tads.*;

public class Cliente implements Comparable<Cliente> {

    private String nombre;
    private String ci;
    private int tel;
    private PilaNodo<Pedido> pedidosCliente;
    private int cantPedidosRegistrados = 0;
    private ListaNodo<Pedido> pedidosCerradosProcesados;

    public Cliente(String unNombre, String unaCi, int unTelefono) {
        this.setNombre(unNombre);
        this.setCi(unaCi);
        this.setTel(unTelefono);
        this.pedidosCliente = new PilaNodo<Pedido>();
        this.pedidosCerradosProcesados = new ListaNodo<Pedido>();
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the ci
     */
    public String getCi() {
        return ci;
    }

    /**
     * @param ci the ci to set
     */
    public void setCi(String ci) {
        this.ci = ci;
    }

    /**
     * @return the tel
     */
    public int getTel() {
        return tel;
    }

    /**
     * @param tel the tel to set
     */
    public void setTel(int tel) {
        this.tel = tel;
    }

    public PilaNodo<Pedido> getPedidosCliente() {
        return pedidosCliente;
    }

    public void setPedidosCliente(Pedido pedidos) {
        this.pedidosCliente.apilar(pedidos);
    }

    public ListaNodo<Pedido> getPedidosCerradosProcesados() {
        return pedidosCerradosProcesados;
    }

    public void setPedidosCerradosProcesados(Pedido pedido) {
        this.pedidosCerradosProcesados.agregarFinal(pedido);
    }

    public int getCantPedidosRegistrados() {
        return cantPedidosRegistrados;
    }

    public void setCantPedidosRegistrados(int unidades) {
        this.cantPedidosRegistrados = unidades;
    }

    public boolean equals(Object a) {
        Cliente c = (Cliente) a;
        return this.getCi().equals(c.getCi());
    }

    @Override
    public String toString() {
        return "Nombre: " + this.getNombre() + " CI: " + this.getCi() + " Cant Pedidos: " + this.getPedidosCliente().elementos() + " Pedidos registrados: " + this.getCantPedidosRegistrados() + "\n";
    }

    @Override
    public int compareTo(Cliente o) {
        //Cliente otro = (Cliente) o;
        return this.getNombre().compareTo(o.getNombre());
    }

    
}
