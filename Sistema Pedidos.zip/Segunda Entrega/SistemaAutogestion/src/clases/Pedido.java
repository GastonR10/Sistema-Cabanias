package clases;

import tads.PilaNodo;

public class Pedido implements Comparable<Pedido> {

    private int idPedido;
    public static int ultimoId = 1;
    private String ciCliente;
    private String estado;
    private PilaNodo<Linea> lineas;
    private int cantUnidades;

    public Pedido(String cedula) {
        this.setIdPedido(ultimoId);
        this.setCiCliente(cedula);
        this.setEstado("abierto");
        this.lineas = new PilaNodo<Linea>();
        this.cantUnidades = 0;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPed) {
        this.idPedido = idPed;
    }

    public String getCiCliente() {
        return ciCliente;
    }

    public void setCiCliente(String ci) {
        this.ciCliente = ci;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estadoNuevo) {
        this.estado = estadoNuevo;
    }

    public PilaNodo<Linea> getLineas() {
        return lineas;
    }

    public void setLineas(Linea nuevaLinea) {
        this.lineas.apilar(nuevaLinea);
        this.setCantUnidades(nuevaLinea.getCantidad());
    }

    public int getCantUnidades() {
        return cantUnidades;
    }

    public void setCantUnidades(int cantidad) {
        this.cantUnidades += cantidad;
    }

    @Override
    public int compareTo(Pedido o) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String toString() {
        return "ID Pedido: " + this.getIdPedido() + " CI Cliente: " + this.getCiCliente() + " Estado: " + this.getEstado() + " Total unidades: " + this.getCantUnidades() + "\n" + this.getLineas().mostrarPila() + "\n" + "---------------------------------------";
    }
    
   
   
    
}
